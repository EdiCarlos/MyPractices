﻿using System.Reflection;
using SalarSoft.ASProxy;

[assembly: AssemblyTitle("Surf the web with ASProxy")]
[assembly: AssemblyDescription("This is a free and open source tool for humanity.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SalarSoft")]
[assembly: AssemblyProduct("ASProxy, is an ASP.NET Proxy")]
[assembly: AssemblyCopyright("Mozilla Public License MPL 1.1/GPL 2.0")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion(Consts.General.ASProxyVersionFull)]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]