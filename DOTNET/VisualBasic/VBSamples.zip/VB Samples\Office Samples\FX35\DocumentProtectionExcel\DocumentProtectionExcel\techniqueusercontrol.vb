﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)

Imports System.Globalization
Public Class TechniqueUserControl

    ''' <summary>
    ''' Binds dataDataGridView to data source.
    ''' </summary>
    Private Sub TechniqueUserControl_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            dataDataGridView.DataSource = Globals.ThisWorkbook.custBindingSource
        Catch ex As Exception
            MessageBox.Show(ex.Message, _
                      "Error setting DataSource for dataDataGridView control.", _
                      MessageBoxButtons.OK, _
                      MessageBoxIcon.Error, _
                      MessageBoxDefaultButton.Button1)
        End Try

    End Sub

    ''' <summary>
    ''' Writes value into dateDateTimePicker control, writes value into read
    ''' only dateTextBox by changing its ReadOnly property to False, setting 
    ''' the Text property and restoring the property value afterwards.
    ''' </summary>
    ''' <param name="sender">Unused.</param>
    ''' <param name="e">Unused.</param>
    ''' <remarks></remarks>
    Private Sub dateDateTimePicker_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dateDateTimePicker.ValueChanged
        Try
            ' Writes dateDateTimePicker value into dateNamedRange 
            Globals.Sheet1.dateNamedRange.Value2 = dateDateTimePicker.Value
            Try
                ' Unprotects TextBox value on Sheet1.
                Globals.Sheet1.dateTextBox.ReadOnly = False
                ' Writes dateDateTimePicker value into dateTextBox in ShortDatePattern.
                Globals.Sheet1.dateTextBox.Text = dateDateTimePicker.Value.ToString("d", DateTimeFormatInfo.CurrentInfo)
            Finally
                ' Protects TextBox value on Sheet1.
                Globals.Sheet1.dateTextBox.ReadOnly = True
            End Try
        Catch ex As Exception
            MessageBox.Show(ex.Message, _
                       "Error changing dateNamedRange and dateTextBox value.", _
                       MessageBoxButtons.OK, _
                       MessageBoxIcon.Error, _
                       MessageBoxDefaultButton.Button1)
        End Try

    End Sub

End Class
