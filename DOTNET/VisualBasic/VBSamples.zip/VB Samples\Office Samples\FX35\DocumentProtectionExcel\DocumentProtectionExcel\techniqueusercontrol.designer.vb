﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class TechniqueUserControl
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.technique1Label = New System.Windows.Forms.Label
        Me.dataLabel = New System.Windows.Forms.Label
        Me.dataDataGridView = New System.Windows.Forms.DataGridView
        Me.technique2Label = New System.Windows.Forms.Label
        Me.dateLabel = New System.Windows.Forms.Label
        Me.dateDateTimePicker = New System.Windows.Forms.DateTimePicker
        CType(Me.dataDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'technique1Label
        '
        Me.technique1Label.AutoSize = True
        Me.technique1Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.technique1Label.Location = New System.Drawing.Point(13, 13)
        Me.technique1Label.Name = "technique1Label"
        Me.technique1Label.Size = New System.Drawing.Size(74, 13)
        Me.technique1Label.TabIndex = 0
        Me.technique1Label.Text = "Technique 1"
        '
        'dataLabel
        '
        Me.dataLabel.AutoSize = True
        Me.dataLabel.Location = New System.Drawing.Point(13, 40)
        Me.dataLabel.Name = "dataLabel"
        Me.dataLabel.Size = New System.Drawing.Size(128, 13)
        Me.dataLabel.TabIndex = 1
        Me.dataLabel.Text = "Modify customer data here"
        '
        'dataDataGridView
        '
        Me.dataDataGridView.Location = New System.Drawing.Point(13, 70)
        Me.dataDataGridView.Name = "dataDataGridView"
        Me.dataDataGridView.Size = New System.Drawing.Size(183, 87)
        Me.dataDataGridView.TabIndex = 2
        Me.dataDataGridView.Text = "DataGridView1"
        '
        'technique2Label
        '
        Me.technique2Label.AutoSize = True
        Me.technique2Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.technique2Label.Location = New System.Drawing.Point(13, 184)
        Me.technique2Label.Name = "technique2Label"
        Me.technique2Label.Size = New System.Drawing.Size(74, 13)
        Me.technique2Label.TabIndex = 3
        Me.technique2Label.Text = "Technique 2"
        '
        'dateLabel
        '
        Me.dateLabel.AutoSize = True
        Me.dateLabel.Location = New System.Drawing.Point(13, 214)
        Me.dateLabel.Name = "dateLabel"
        Me.dateLabel.Size = New System.Drawing.Size(66, 13)
        Me.dateLabel.TabIndex = 4
        Me.dateLabel.Text = "Select a date"
        '
        'dateDateTimePicker
        '
        Me.dateDateTimePicker.Location = New System.Drawing.Point(13, 244)
        Me.dateDateTimePicker.Name = "dateDateTimePicker"
        Me.dateDateTimePicker.Size = New System.Drawing.Size(183, 20)
        Me.dateDateTimePicker.TabIndex = 5
        '
        'TechniqueUserControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.dateDateTimePicker)
        Me.Controls.Add(Me.dateLabel)
        Me.Controls.Add(Me.technique2Label)
        Me.Controls.Add(Me.dataDataGridView)
        Me.Controls.Add(Me.dataLabel)
        Me.Controls.Add(Me.technique1Label)
        Me.MinimumSize = New System.Drawing.Size(210, 313)
        Me.Name = "TechniqueUserControl"
        Me.Size = New System.Drawing.Size(210, 313)
        CType(Me.dataDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents technique1Label As System.Windows.Forms.Label
    Friend WithEvents dataLabel As System.Windows.Forms.Label
    Friend WithEvents dataDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents technique2Label As System.Windows.Forms.Label
    Friend WithEvents dateLabel As System.Windows.Forms.Label
    Friend WithEvents dateDateTimePicker As System.Windows.Forms.DateTimePicker

End Class
