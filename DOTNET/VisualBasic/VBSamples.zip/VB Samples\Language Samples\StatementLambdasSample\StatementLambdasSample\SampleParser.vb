﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
Imports System.Reflection

Public Class SampleParser
    Private _filePath As String
    Private _sampleInstance As Samples

    Public Sub New(ByVal sampleInstance As Samples, ByVal filePath As String)
        _filePath = filePath
        _sampleInstance = sampleInstance
    End Sub

    Public Function GetSampleInfo() As List(Of SampleInfo)
        Dim file As IO.StreamReader
        Try
            file = My.Computer.FileSystem.OpenTextFileReader(_filePath)
        Catch
            Return Nothing
        End Try

        Dim sampleList As New List(Of SampleInfo)

        Dim line As String
        Dim commentText As String
        Dim sampleElement As XElement
        Dim sInfo As SampleInfo

        While Not file.EndOfStream
            line = file.ReadLine()
            If Left(Trim(line), 1) = "'" Then
                commentText = Mid(Trim(line), 2)
                If InStr(commentText, "<Sample ") > 0 Then
                    sampleElement = XElement.Parse(commentText)
                    sInfo = New SampleInfo With {.ID = sampleElement.@ID,
                                                 .MethodName = sampleElement.@MethodName,
                                                 .Description = sampleElement.@Description}
                    line = file.ReadLine()
                    While Not file.EndOfStream AndAlso Not EndOfSample(line, sampleElement.@ID)
                        sInfo.SampleText &= line & vbCrLf
                        line = file.ReadLine()
                    End While

                    sampleList.Add(sInfo)
                End If
            End If
        End While

        file.Close()

        Return sampleList
    End Function

    Private Function EndOfSample(ByVal line As String, ByVal id As String) As Boolean
        Dim endElement As XElement
        Dim commentText As String

        If Left(Trim(line), 1) = "'" Then
            commentText = Mid(Trim(line), 2)
            If InStr(commentText, "<EndSample ") > 0 Then
                endElement = XElement.Parse(commentText)
                If endElement.@ID = id Then Return True
            End If
        End If

        Return False
    End Function

    Public Function GetSampleResults(ByVal methodName As String, ByVal p1 As Object, ByVal p2 As Object) As String
        Dim sampleMethod = _sampleInstance.GetType().GetMethod(methodName)
        Dim sampleParameters() As Object
        ReDim sampleParameters(sampleMethod.GetParameters().Count - 1)
        If sampleParameters.Count > 0 Then sampleParameters(0) = p1
        If sampleParameters.Count > 1 Then sampleParameters(1) = p2
        Try
            Return sampleMethod.Invoke(_sampleInstance, sampleParameters).ToString()
        Catch
            Return "Method not invoked. You may need to specify input parameters."
        End Try
    End Function

End Class

Public Class SampleInfo
    Public Property ID() As String
    Public Property MethodName() As String
    Public Property Description() As String
    Public Property SampleText() As String
End Class


