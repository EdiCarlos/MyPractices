﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
Option Strict On
Option Explicit On

Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Data.Linq
Imports System.Data.Linq.Mapping
Imports System.Linq
Imports System.Linq.Expressions
Imports System.Reflection

Partial Public Class CustomerDataContext
    Public Sub New()
        MyBase.New(Global.BdcSampleVB.Settings.Default.NORTHWNDConnectionString, mappingSource)
        OnCreated()
    End Sub
End Class
