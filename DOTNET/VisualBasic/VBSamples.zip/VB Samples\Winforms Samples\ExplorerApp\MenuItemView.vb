﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
' Copyright (c) Microsoft Corporation. All rights reserved.
' This class simply extends the MenuItem class to support a View property.
Class MenuItemView
    Inherits ToolStripMenuItem
    Public View As View
End Class
