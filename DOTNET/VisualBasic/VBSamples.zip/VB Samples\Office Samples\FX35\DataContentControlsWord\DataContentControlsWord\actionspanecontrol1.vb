﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)

Public Class ActionsPaneControl1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Globals.ThisDocument.EmployeesBindingSource.MovePrevious()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Globals.ThisDocument.EmployeesBindingSource.MoveNext()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim foundIndex As Integer
        Dim currentIndex As Integer

        currentIndex = Globals.ThisDocument.EmployeesBindingSource.Position

        foundIndex = Globals.ThisDocument.EmployeesBindingSource.Find("EmployeeID", TextBox1.Text)
        If (foundIndex < 0) Then
            'Prompt user for a valid ID because the value entered could not be found    
            MessageBox.Show("Please enter a valid ID!")
            Globals.ThisDocument.EmployeesBindingSource.Position = currentIndex
        Else
            'Move to the record found
            Globals.ThisDocument.EmployeesBindingSource.Position = foundIndex
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Globals.ThisDocument.PlainTextContentControl4.DataBindings("Text").WriteValue()
        Globals.ThisDocument.EmployeesBindingSource.EndEdit()
        Globals.ThisDocument.EmployeesTableAdapter.Update(Globals.ThisDocument.NorthwindDataSet.Employees)
        MsgBox("Title Updated")

    End Sub
End Class
