﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)

<System.ComponentModel.ToolboxItemAttribute(False)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RssRegion
    Inherits Microsoft.Office.Tools.Outlook.FormRegionBase

    Public Sub New(ByVal formRegion As Microsoft.Office.Interop.Outlook.FormRegion)
        MyBase.New(Globals.Factory, formRegion)
        Me.InitializeComponent()
    End Sub

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RssRegionSplitContainer = New System.Windows.Forms.SplitContainer()
        Me.webBrowserRss = New System.Windows.Forms.WebBrowser()
        Me.viewRssToolStrip = New System.Windows.Forms.ToolStrip()
        Me.searchSimilarTopicsButton = New System.Windows.Forms.ToolStripButton()
        Me.viewRssBackButton = New System.Windows.Forms.ToolStripButton()
        Me.viewRssProgressBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.webBrowserSearch = New System.Windows.Forms.WebBrowser()
        Me.searchResultsToolStrip = New System.Windows.Forms.ToolStrip()
        Me.hideSearchResultsButton = New System.Windows.Forms.ToolStripButton()
        Me.searchResultsBackButton = New System.Windows.Forms.ToolStripButton()
        Me.searchWindowProgressBar = New System.Windows.Forms.ToolStripProgressBar()
        CType(Me.RssRegionSplitContainer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RssRegionSplitContainer.Panel1.SuspendLayout()
        Me.RssRegionSplitContainer.Panel2.SuspendLayout()
        Me.RssRegionSplitContainer.SuspendLayout()
        Me.viewRssToolStrip.SuspendLayout()
        Me.searchResultsToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'RssRegionSplitContainer
        '
        Me.RssRegionSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RssRegionSplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.RssRegionSplitContainer.Name = "RssRegionSplitContainer"
        '
        'RssRegionSplitContainer.Panel1
        '
        Me.RssRegionSplitContainer.Panel1.Controls.Add(Me.webBrowserRss)
        Me.RssRegionSplitContainer.Panel1.Controls.Add(Me.viewRssToolStrip)
        '
        'RssRegionSplitContainer.Panel2
        '
        Me.RssRegionSplitContainer.Panel2.Controls.Add(Me.webBrowserSearch)
        Me.RssRegionSplitContainer.Panel2.Controls.Add(Me.searchResultsToolStrip)
        Me.RssRegionSplitContainer.Size = New System.Drawing.Size(800, 525)
        Me.RssRegionSplitContainer.SplitterDistance = 400
        Me.RssRegionSplitContainer.TabIndex = 0
        '
        'webBrowserRss
        '
        Me.webBrowserRss.Dock = System.Windows.Forms.DockStyle.Fill
        Me.webBrowserRss.Location = New System.Drawing.Point(0, 25)
        Me.webBrowserRss.MinimumSize = New System.Drawing.Size(20, 20)
        Me.webBrowserRss.Name = "webBrowserRss"
        Me.webBrowserRss.Size = New System.Drawing.Size(400, 500)
        Me.webBrowserRss.TabIndex = 2
        '
        'viewRssToolStrip
        '
        Me.viewRssToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.viewRssToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.searchSimilarTopicsButton, Me.viewRssBackButton, Me.viewRssProgressBar})
        Me.viewRssToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.viewRssToolStrip.Name = "viewRssToolStrip"
        Me.viewRssToolStrip.Size = New System.Drawing.Size(400, 25)
        Me.viewRssToolStrip.TabIndex = 1
        Me.viewRssToolStrip.Text = "viewRssToolStrip"
        '
        'searchSimilarTopicsButton
        '
        Me.searchSimilarTopicsButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.searchSimilarTopicsButton.Checked = True
        Me.searchSimilarTopicsButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.searchSimilarTopicsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.searchSimilarTopicsButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.searchSimilarTopicsButton.Name = "searchSimilarTopicsButton"
        Me.searchSimilarTopicsButton.Size = New System.Drawing.Size(127, 22)
        Me.searchSimilarTopicsButton.Text = "Search for Similar Topics"
        '
        'viewRssBackButton
        '
        Me.viewRssBackButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.viewRssBackButton.Checked = True
        Me.viewRssBackButton.CheckOnClick = True
        Me.viewRssBackButton.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Me.viewRssBackButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.viewRssBackButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.viewRssBackButton.Name = "viewRssBackButton"
        Me.viewRssBackButton.Size = New System.Drawing.Size(51, 22)
        Me.viewRssBackButton.Text = "   Back   "
        Me.viewRssBackButton.ToolTipText = "Back"
        '
        'viewRssProgressBar
        '
        Me.viewRssProgressBar.Name = "viewRssProgressBar"
        Me.viewRssProgressBar.Size = New System.Drawing.Size(100, 22)
        Me.viewRssProgressBar.Step = 20
        Me.viewRssProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.viewRssProgressBar.ToolTipText = "View Article Progress Bar"
        Me.viewRssProgressBar.Value = 15
        '
        'webBrowserSearch
        '
        Me.webBrowserSearch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.webBrowserSearch.Location = New System.Drawing.Point(0, 25)
        Me.webBrowserSearch.MinimumSize = New System.Drawing.Size(20, 20)
        Me.webBrowserSearch.Name = "webBrowserSearch"
        Me.webBrowserSearch.Size = New System.Drawing.Size(396, 500)
        Me.webBrowserSearch.TabIndex = 2
        '
        'searchResultsToolStrip
        '
        Me.searchResultsToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.searchResultsToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.hideSearchResultsButton, Me.searchResultsBackButton, Me.searchWindowProgressBar})
        Me.searchResultsToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.searchResultsToolStrip.Name = "searchResultsToolStrip"
        Me.searchResultsToolStrip.Size = New System.Drawing.Size(396, 25)
        Me.searchResultsToolStrip.TabIndex = 1
        Me.searchResultsToolStrip.Text = "SearchResultsToolStrip"
        '
        'hideSearchResultsButton
        '
        Me.hideSearchResultsButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.hideSearchResultsButton.Checked = True
        Me.hideSearchResultsButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.hideSearchResultsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.hideSearchResultsButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.hideSearchResultsButton.Name = "hideSearchResultsButton"
        Me.hideSearchResultsButton.Size = New System.Drawing.Size(106, 22)
        Me.hideSearchResultsButton.Text = "Hide Search Results"
        '
        'searchResultsBackButton
        '
        Me.searchResultsBackButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.searchResultsBackButton.Checked = True
        Me.searchResultsBackButton.CheckOnClick = True
        Me.searchResultsBackButton.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Me.searchResultsBackButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.searchResultsBackButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.searchResultsBackButton.Name = "searchResultsBackButton"
        Me.searchResultsBackButton.Size = New System.Drawing.Size(51, 22)
        Me.searchResultsBackButton.Text = "   Back   "
        Me.searchResultsBackButton.ToolTipText = "Back"
        '
        'searchWindowProgressBar
        '
        Me.searchWindowProgressBar.Name = "searchWindowProgressBar"
        Me.searchWindowProgressBar.Size = New System.Drawing.Size(100, 22)
        Me.searchWindowProgressBar.Step = 20
        Me.searchWindowProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.searchWindowProgressBar.ToolTipText = "Search Window Progress Bar"
        Me.searchWindowProgressBar.Value = 15
        '
        'RssRegion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.RssRegionSplitContainer)
        Me.Name = "RssRegion"
        Me.Size = New System.Drawing.Size(800, 525)
        Me.RssRegionSplitContainer.Panel1.ResumeLayout(False)
        Me.RssRegionSplitContainer.Panel1.PerformLayout()
        Me.RssRegionSplitContainer.Panel2.ResumeLayout(False)
        Me.RssRegionSplitContainer.Panel2.PerformLayout()
        CType(Me.RssRegionSplitContainer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RssRegionSplitContainer.ResumeLayout(False)
        Me.viewRssToolStrip.ResumeLayout(False)
        Me.viewRssToolStrip.PerformLayout()
        Me.searchResultsToolStrip.ResumeLayout(False)
        Me.searchResultsToolStrip.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    'NOTE: The following procedure is required by the Form Regions Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Shared Sub InitializeManifest(ByVal manifest As Microsoft.Office.Tools.Outlook.FormRegionManifest)
        manifest.FormRegionName = "View Article"
        manifest.Icons.Page = Global.FormRegionOutlookAddIn.My.Resources.rssfeed

    End Sub

    Private WithEvents RssRegionSplitContainer As System.Windows.Forms.SplitContainer
    Private WithEvents viewRssToolStrip As System.Windows.Forms.ToolStrip
    Private WithEvents searchSimilarTopicsButton As System.Windows.Forms.ToolStripButton
    Private WithEvents viewRssBackButton As System.Windows.Forms.ToolStripButton
    Private WithEvents viewRssProgressBar As System.Windows.Forms.ToolStripProgressBar
    Private WithEvents webBrowserRss As System.Windows.Forms.WebBrowser
    Private WithEvents searchResultsToolStrip As System.Windows.Forms.ToolStrip
    Private WithEvents hideSearchResultsButton As System.Windows.Forms.ToolStripButton
    Private WithEvents searchResultsBackButton As System.Windows.Forms.ToolStripButton
    Private WithEvents searchWindowProgressBar As System.Windows.Forms.ToolStripProgressBar
    Private WithEvents webBrowserSearch As System.Windows.Forms.WebBrowser

    Partial Public Class RssRegionFactory
        Implements Microsoft.Office.Tools.Outlook.IFormRegionFactory

        Public Event FormRegionInitializing As Microsoft.Office.Tools.Outlook.FormRegionInitializingEventHandler

        Private _Manifest As Microsoft.Office.Tools.Outlook.FormRegionManifest


        <System.Diagnostics.DebuggerNonUserCodeAttribute()> _
        Public Sub New()
            Me._Manifest = Globals.Factory.CreateFormRegionManifest()
            RssRegion.InitializeManifest(Me._Manifest)
        End Sub

        <System.Diagnostics.DebuggerNonUserCodeAttribute()> _
        ReadOnly Property Manifest() As Microsoft.Office.Tools.Outlook.FormRegionManifest Implements Microsoft.Office.Tools.Outlook.IFormRegionFactory.Manifest
            Get
                Return Me._Manifest
            End Get
        End Property

        <System.Diagnostics.DebuggerNonUserCodeAttribute()> _
        Function CreateFormRegion(ByVal formRegion As Microsoft.Office.Interop.Outlook.FormRegion) As Microsoft.Office.Tools.Outlook.IFormRegion Implements Microsoft.Office.Tools.Outlook.IFormRegionFactory.CreateFormRegion
            Dim form As RssRegion = New RssRegion(formRegion)
            form.Factory = Me
            Return form
        End Function

        <System.Diagnostics.DebuggerNonUserCodeAttribute()> _
        Function GetFormRegionStorage(ByVal outlookItem As Object, ByVal formRegionMode As Microsoft.Office.Interop.Outlook.OlFormRegionMode, ByVal formRegionSize As Microsoft.Office.Interop.Outlook.OlFormRegionSize) As Byte() Implements Microsoft.Office.Tools.Outlook.IFormRegionFactory.GetFormRegionStorage
            Throw New System.NotSupportedException()
        End Function

        <System.Diagnostics.DebuggerNonUserCodeAttribute()> _
        Function IsDisplayedForItem(ByVal outlookItem As Object, ByVal formRegionMode As Microsoft.Office.Interop.Outlook.OlFormRegionMode, ByVal formRegionSize As Microsoft.Office.Interop.Outlook.OlFormRegionSize) As Boolean Implements Microsoft.Office.Tools.Outlook.IFormRegionFactory.IsDisplayedForItem
            Dim cancelArgs As Microsoft.Office.Tools.Outlook.FormRegionInitializingEventArgs = Globals.Factory.CreateFormRegionInitializingEventArgs(outlookItem, formRegionMode, formRegionSize, False)
            cancelArgs.Cancel = False
            RaiseEvent FormRegionInitializing(Me, cancelArgs)
            Return Not cancelArgs.Cancel
        End Function

        <System.Diagnostics.DebuggerNonUserCodeAttribute()> _
        ReadOnly Property Kind() As Microsoft.Office.Tools.Outlook.FormRegionKindConstants Implements Microsoft.Office.Tools.Outlook.IFormRegionFactory.Kind
            Get
                Return Microsoft.Office.Tools.Outlook.FormRegionKindConstants.WindowsForms
            End Get
        End Property
    End Class
End Class

Partial Class WindowFormRegionCollection

    Friend ReadOnly Property RssRegion() As RssRegion
        Get
            For Each Item As Object In Me
                If (TypeOf (Item) Is RssRegion) Then
                    Return Item
                End If
            Next
            Return Nothing
        End Get
    End Property
End Class