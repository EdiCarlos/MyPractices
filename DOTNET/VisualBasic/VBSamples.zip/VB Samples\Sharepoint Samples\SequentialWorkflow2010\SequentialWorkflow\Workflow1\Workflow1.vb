﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)

Imports Microsoft.SharePoint.Workflow
Imports System.Workflow.Activities

Public Class Workflow1
    Inherits SequentialWorkflowActivity

    Public workflowProperties As New SPWorkflowActivationProperties

    Public Sub New()
        MyBase.New()
        InitializeComponent()
    End Sub
    Public taskId1 As System.Guid = Nothing
    Public taskProperties As SPWorkflowTaskProperties = New Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties
    Public afterProperties As SPWorkflowTaskProperties = New Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties
    Public beforeProperties1 As SPWorkflowTaskProperties = New Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties
    Private taskCompleted As Boolean = False

    Private Sub createTask1_MethodInvoking(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Task must have a guid
        taskId1 = Guid.NewGuid()
        With taskProperties
            'Setting up the basic task properties
            .PercentComplete = 0.0
            .AssignedTo = System.Threading.Thread.CurrentPrincipal.Identity.Name
            .TaskType = 0
            .DueDate = DateTime.Now.AddDays(7)
            .StartDate = DateTime.Now()
            .Title = "SharePoint Workflow Task"
        End With
    End Sub

    'This procedure evaluates False when the task has been changed to 100% complete
    Private Sub notCompleted(ByVal sender As System.Object, ByVal e As System.Workflow.Activities.ConditionalEventArgs)
        'The result must be 1.0 for the task to be complete
        e.Result = Not taskCompleted
    End Sub

    Private Sub onTaskChanged1_Invoked(ByVal sender As System.Object, ByVal e As System.Workflow.Activities.ExternalDataEventArgs)
        'Checking the task properties after the change.
        'Looking for 1.0 to reflect a completed task.
        If afterProperties.PercentComplete = 1.0 Then
            taskCompleted = True
        End If
    End Sub
End Class