﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SimpleControl
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SimpleControl))
        Me.insertTextBox = New System.Windows.Forms.TextBox
        Me.insertButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'insertTextBox
        '
        resources.ApplyResources(Me.insertTextBox, "insertTextBox")
        Me.insertTextBox.Name = "insertTextBox"
        '
        'insertButton
        '
        resources.ApplyResources(Me.insertButton, "insertButton")
        Me.insertButton.Name = "insertButton"
        Me.insertButton.UseVisualStyleBackColor = True
        '
        'SimpleControl
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.insertButton)
        Me.Controls.Add(Me.insertTextBox)
        Me.Name = "SimpleControl"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents insertTextBox As System.Windows.Forms.TextBox
    Friend WithEvents insertButton As System.Windows.Forms.Button

End Class
