﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)


Public Class ListProperties


    Private _listTitle As String
    Public Property ListTitle() As String
        Get
            Return _listTitle
        End Get
        Set(ByVal value As String)
            _listTitle = value
        End Set
    End Property

    Private _itemCount As Integer
    Public Property ItemCount() As Integer
        Get
            Return _itemCount
        End Get
        Set(ByVal value As Integer)
            _itemCount = value
        End Set
    End Property


    Private _fieldCount As Integer
    Public Property FieldCount() As Integer
        Get
            Return _fieldCount
        End Get
        Set(ByVal value As Integer)
            _fieldCount = value
        End Set
    End Property

    Private _folderCount As Integer
    Public Property FolderCount() As Integer
        Get
            Return _folderCount
        End Get
        Set(ByVal value As Integer)
            _folderCount = value
        End Set
    End Property

    Private _viewCount As Integer
    Public Property ViewCount() As Integer
        Get
            Return _viewCount
        End Get
        Set(ByVal value As Integer)
            _viewCount = value
        End Set
    End Property

    Private _workflowCount As Integer
    Public Property WorkflowCount() As Integer
        Get
            Return _workflowCount
        End Get
        Set(ByVal value As Integer)
            _workflowCount = value
        End Set
    End Property










End Class
