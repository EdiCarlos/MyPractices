﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)

Public Class ThisDocument

    Private myActionsPane As New ActionsPaneControl1

    Private Sub ThisDocument_Startup() Handles Me.Startup
        'TODO: Delete this line of code to remove the default AutoFill for 'NorthwindDataSet.Employees'.
        If Me.NeedsFill("NorthwindDataSet") Then
            Me.EmployeesTableAdapter.Fill(Me.NorthwindDataSet.Employees)
        End If
        Me.ActionsPane.Controls.Add(MyActionsPane)
    End Sub

    Private Sub ThisDocument_Shutdown() Handles Me.Shutdown

    End Sub

End Class
