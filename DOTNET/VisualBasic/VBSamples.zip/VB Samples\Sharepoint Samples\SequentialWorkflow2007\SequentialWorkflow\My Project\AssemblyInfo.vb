﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
' THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
' ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
' THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
' PARTICULAR PURPOSE.
'
' Copyright (c) Microsoft Corporation. All rights reserved.

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("SequentialWorkflow")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("SequentialWorkflow")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft 2009")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("0c672173-2d62-4512-b569-7b38320fdd81")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 