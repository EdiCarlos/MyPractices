﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)


Public Class Helper

    ' Return the url of the "View article" link that appears in the headline of the RSS item. 
    Public Shared Function ParseUrl(ByVal item As Outlook.PostItem) As String

        Const lookUpText As String = "HYPERLINK"
        Const articleStr As String = "View article"
        Dim body As String = item.Body

        Dim index As Integer = body.IndexOf(lookUpText, 0, body.Length)
        Dim endIndex As Integer = 0

        ' Look through body for "HYPERLINKS" and narrow down to "View article..." link.
        While True
            endIndex = body.IndexOf(articleStr, index, body.Length - index)
            Dim nextIndex As Integer = body.IndexOf(lookUpText, index + 1, body.Length - (index + 1))

            If nextIndex > index And nextIndex < endIndex Then
                index = nextIndex
            Else
                Exit While
            End If
        End While

        ' Get the Link to the article.
        Dim url As String = body.Substring(index + lookUpText.Length + 1, endIndex - index - (lookUpText.Length + 1))

        url = url.Trim("""")

        Return url

    End Function

End Class
