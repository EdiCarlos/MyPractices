﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)

Public Class Sheet3

    Private Sub Sheet3_Startup() Handles Me.Startup

    End Sub

    Private Sub Sheet3_Shutdown() Handles Me.Shutdown

    End Sub

End Class
