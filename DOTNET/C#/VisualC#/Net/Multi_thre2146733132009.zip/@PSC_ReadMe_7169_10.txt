Title: Multi threaded Port Scanner (Scans both IP and Port ranges)
Description: This application is like any other port scanner, it can scan a range of Ports (TCP) at a single ip address or accross a range of ip addresses.
Bare in-mind that this is my first project in C, i've only ever used VB before so expect alot of silly/nooby mistakes ;)
All feedback is welcome, thanks :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7169&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
