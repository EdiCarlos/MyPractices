﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;

namespace CustomErrorProvider
{
    [ToolboxBitmap(typeof(CustomError), "CustomError.ico")]
    public class CustomError : Component
    {
        ErrorProvider _errorProvider = new ErrorProvider();
        Control _controlToValidate;
        Control[] _controlsToValidate;
        [Description("gets or sets the value to validate")]
        public Control[] ControlsToValidate
        {
            get { return _controlsToValidate; }
            set 
            {
                _controlsToValidate = value;
                if ((_controlsToValidate != null) && (!DesignMode))
                {
                    foreach (Control cntr in _controlsToValidate)
                    {
                        cntr.Validating += new CancelEventHandler(_controlToValidate_Validating);
                    }
                }
            }
        }
        string _errorMessage = "Default Error was not Set";
        [Category("Behaviour")]
        [Description("Gets or sets the control to validate.")]
        [Browsable(true)]
        public Control ControlToValidate
        {
            get { return _controlToValidate; }
            set
            {
                _controlToValidate = value;
                // Hook up ControlToValidate's Validating event
                // at run-time ie not from VS.NET
                if ((_controlToValidate != null) && (!DesignMode))
                {
                    _controlToValidate.Validating += new CancelEventHandler(_controlToValidate_Validating);
                }
            }
        }
        //[Browsable(true)]
        //[Description("Gets Controls")]
        //public Control ControlsToValidate
        //{
        //    get{retur
        //}
        [Description("Gets or Sets the Error Message")]
        public string ErrorMessage
        {
            get { return _errorMessage; }
            set
            {
                _errorMessage = value;
            }
        }
        void _controlToValidate_Validating(object sender, CancelEventArgs e)
        {
            //Validate(sender);
            Control lclcontrol = sender as Control;
            if (lclcontrol.Text != null)
            {
                if (lclcontrol.Text.Equals(string.Empty))
                {
                    _errorProvider.SetError(lclcontrol, ErrorMessage);
                    e.Cancel = true;
                    return;
                }
            }
        }
        
    }
}
