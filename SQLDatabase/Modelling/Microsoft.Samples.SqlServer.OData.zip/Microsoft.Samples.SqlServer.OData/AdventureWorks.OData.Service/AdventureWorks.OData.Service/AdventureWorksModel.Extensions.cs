﻿// Copyright Microsoft

using System.Data.Services.Common;

namespace Microsoft.Samples.SqlServer.AdventureWorksService
{
    [NamedStream("LargePhoto")]
    [NamedStream("ThumbNailPhoto")]
    public partial class vProductCatalog { }
}